"""
This is one of those "bad" modules that hopefully goes away one day. It
basically contains code that should be somewhere else at the moment.
"""
import abc
import datetime as dt
import functools
import logging
import os.path
import random
import tempfile
from contextlib import contextmanager
from enum import Enum
import glob

import luigi
import luigi.contrib.hdfs
import luigi.contrib.spark
import luigi.task
import luigi.task_register
import luigi.contrib.hdfs.webhdfs_client as hdfs_client
import config.Config as config

logger = logging.getLogger(__name__)
luigi.task.namespace(__name__)
DM_DIR = '/data/zte/rd/user_interest_v2/'


def _hadoopcli_client():
    return luigi.contrib.hdfs.HdfsClient()


def _put(src, des):
    _hadoopcli_client().mkdir(des)
    _hadoopcli_client().put(src, des)


def _next_task(task, cls_name):
    new_family = task.get_task_namespace() + "." + cls_name
    return luigi.task_register.Register.get_task_cls(new_family)


def _params(task):
    return {k: getattr(task, k) for (k, _) in task.get_params()}


@contextmanager
def _downloaded(hdfs_path):
    client = _hadoopcli_client()
    tempfile.tempdir = "/data/zte/zmining/zudm_user_interest/"
    with tempfile.TemporaryDirectory(suffix='user_interest') as td_path:
        tmppath = os.path.join(td_path, 'from_hadoop')
        client.get(hdfs_path, tmppath)
        yield tmppath


class Duration(Enum):
    d01 = 1
    d07 = 2
    d30 = 3
    d90 = 4
    inf = 5
    d100 = 6

    def calc_priority(self):
        # I call this calc_priority as it's not a @property
        return 6 - self.value

    def dependencies(self, date):
        """
        Return tuples like  either (range, date) or ('basecase', date_hour)
        """
        if self is Duration.d01:
            for i in range(24):
                new_date_hour = dt.datetime.combine(date, dt.time(hour=i))
                yield 'basecase', new_date_hour
        elif self is Duration.d07:
            for i in range(7):
                new_date = date - dt.timedelta(days=i)
                yield Duration.d01, new_date
        elif self is Duration.d100:
            for i in range(90):
                new_date = date - dt.timedelta(days=i)
                yield Duration.d01, new_date
        elif self is Duration.d30:
            for i in range(4):
                new_date = date - dt.timedelta(weeks=i)
                yield Duration.d07, new_date
            for td in (dt.timedelta(days=28), dt.timedelta(days=29)):
                yield Duration.d01, date - td
        elif self is Duration.d90:
            for i in range(3):
                new_date = date - dt.timedelta(days=i * 30)
                yield Duration.d30, new_date


class DDParamsMixin(object):
    date = luigi.DateParameter(positional=False)
    duration = luigi.EnumParameter(enum=Duration)

    def dd_format(self, templated_string, *args, **kwargs):
        return self.date.strftime(
            templated_string.format(*args,
                                    duration_name=self.duration.name,
                                    **kwargs))


class VngHdfsTarget(luigi.contrib.hdfs.HdfsTarget):
    @property
    @functools.lru_cache()
    def fs(self):
        return hdfs_client.WebHdfsClient(host="hadoopmaster22147", port=50070, user="zte")

    def temporary_path(target):
        class Manager(object):
            def __enter__(self):
                path = target.path.rstrip('/')
                num = random.randrange(0, 1e10)
                self.temp_path = path + '-luigi-tmp-{:010}'.format(num)
                return self.temp_path

            def __exit__(self, exc_type, exc_value, traceback):
                if exc_type is None:
                    # There were no exceptions
                    target.fs.rename_dont_move(self.temp_path, target.path)
                return False

        return Manager()


class RecentGenerateTask(luigi.task.WrapperTask):
    date = luigi.DateParameter(default=dt.date.today(), significant=False)
    duration = Duration.d01

    @property
    @abc.abstractmethod
    def next_task(self):
        pass

    @property
    @abc.abstractmethod
    def last_day(self):
        pass

    def requires(self):
        dates = [self.date - dt.timedelta(days=i) for i in range(self.last_day)]
        # dates = [self.date - dt.timedelta(days=2)]

        for date in dates:
            yield _next_task(self, self.next_task)(date=date, duration=self.duration)


class RecentHourlyGenerateTask(RecentGenerateTask):
    date_hour = luigi.DateHourParameter(default=dt.datetime.today(), positional=False)
    last_day = None

    def requires(self):
        for i in range(1, 49):
            last_hour = self.date_hour - dt.timedelta(hours=i)
            yield _next_task(self, self.next_task)(date_hour=last_hour, date=self.date - dt.timedelta(days=1),
                                                   duration=self.duration)


class UploadTask(config.JavaConfig, DDParamsMixin, metaclass=abc.ABCMeta):
    date = luigi.DateParameter(positional=False)
    resource = {"upload_to_db_lock": 1}

    def process_resources(self):
        resources = self.resource
        resources.update(self.resources)
        return resources

    @property
    def upload_date(self):
        return (self.date + dt.timedelta(days=1)).strftime('%Y%m%d') + '24'

    @property
    @abc.abstractmethod
    def db_key(self):
        pass

    @property
    @abc.abstractmethod
    def folder(self):
        pass

    @property
    @abc.abstractmethod
    def next_task(self):
        pass

    def output(self):
        templated_path = self.folder + '/%Y/%m/%d/' \
                                       'UPLOAD_DONE.marker_file'
        return VngHdfsTarget(self.dd_format(templated_path))

    def _touchz(self):
        _hadoopcli_client().touchz(self.output().path)

    def ingest_users_to_db(self):
        with _downloaded(self.input().path) as uids_path:
            program = self.app[
                self.class_path,
                uids_path,
                self.db_key,
                self.upload_date
            ]
            return program()

    def run(self):
        self.ingest_users_to_db()
        self._touchz()

    def requires(self):
        return _next_task(self, self.next_task)(**_params(self))


class HourlyUploadTask(UploadTask):
    date_hour = luigi.DateHourParameter(positional=False)

    @property
    def upload_date(self):
        return (self.date_hour + dt.timedelta(hours=1)).strftime('%Y%m%d%H')

    def output(self):
        templated_path = '{folder}/%Y/%m/%d/%H/' \
                         'UPLOAD_DONE.marker_file'
        path = self.date_hour.strftime(templated_path.format(folder=self.folder))

        return VngHdfsTarget(path)


class JavaTask(config.JavaConfig, metaclass=abc.ABCMeta):
    date = luigi.DateParameter(positional=False)

    @property
    @abc.abstractmethod
    def folder(self):
        pass

    def output(self):
        templated_path = self.folder + '/%Y/%m/%d/'
        path = self.date.strftime(templated_path.format(self.folder))
        return VngHdfsTarget(path)


class FiterBadItems(config.JavaConfig, DDParamsMixin, metaclass=abc.ABCMeta):
    @property
    @abc.abstractmethod
    def folder(self):
        pass

    @property
    @abc.abstractmethod
    def db_key(self):
        pass

    def output(self):
        templated_path = DM_DIR + '{folder}/%Y/%m/%d/'
        path = self.date.strftime(templated_path.format(folder=self.folder))

        return VngHdfsTarget(path)

    def _put(self):
        _hadoopcli_client().mkdir(self.temp_output_path)
        files = [os.path.join(r, file) for r, d, f in os.walk(self.tmppath) for file in d]
        if len(files)==0:
            files = [os.path.join(r, file) for r, d, f in os.walk(self.tmppath) for file in f]
        for file in files:
            _hadoopcli_client().put(file, self.temp_output_path)

    def do_task(self):
        with _downloaded(self.input().path) as uids_path:
            tempfile.tempdir = "/data/zte/zmining/zudm_user_interest/"
            with tempfile.TemporaryDirectory(suffix='user_interest') as td_path:
                self.tmppath = os.path.join(td_path, 'local')
                if not os.path.exists(self.tmppath):
                    os.makedirs(self.tmppath)

                program = self.app[
                    self.class_path,
                    uids_path,
                    self.tmppath,
                    self.db_key]

                program()

                self._put()

    def run(self):
        with self.output().temporary_path() as self.temp_output_path:
            self.do_task()

    def requires(self):
        return _next_task(self, self.next_task)(**_params(self))


class HourlyFiterBadItems(FiterBadItems):
    date_hour = luigi.DateHourParameter(positional=False)

    def output(self):
        templated_path = DM_DIR + '{folder}/%Y/%m/%d/%H/'
        path = self.date_hour.strftime(templated_path.format(folder=self.folder))

        return VngHdfsTarget(path)


class SparkTask(config.SparkConfig, DDParamsMixin, metaclass=abc.ABCMeta):
    date_hour = None

    @property
    def entry_class(self):
        return self.executor

    @property
    @abc.abstractmethod
    def executor(self):
        pass

    @property
    @abc.abstractmethod
    def folder(self):
        pass

    @property
    @abc.abstractmethod
    def next_task(self):
        pass

    @functools.lru_cache()
    def _inputs(self):
        return ['hdfs://hadoopmaster22147:9000'+input.path for input in self.input() if input.exists()]

    def run(self):
        with self.output().temporary_path() as self.temp_output_path:
            if self._inputs():
                # If there is input, use spark
                super().run()
            else:
                print('NO INPUT DATA')

    def app_options(self):
        inputs = ','.join(self._inputs())
        return ['--input', inputs, '--output', 'hdfs://hadoopmaster22147:9000' + self.temp_output_path]

    def output(self):
        templated_path = DM_DIR + '{duration_name}/{folder}/%Y/%m/%d/'

        path = self.dd_format(templated_path, folder=self.folder)
        return VngHdfsTarget(path)

    def requires(self):
        dep_tuples = self.duration.dependencies(self.date)

        for duration, date_ish in dep_tuples:
            if duration == 'basecase':
                date_hour = date_ish
                yield _next_task(self, self.next_task)(date_hour=date_hour, **_params(self))

            else:
                date = date_ish
                yield self.__class__(duration=duration, date=date)


class RootSparkTask(SparkTask):
    def requires(self):
        yield _next_task(self, self.next_task)(**_params(self))


class UnDurationSparkTask(SparkTask):
    def output(self):
        templated_path = DM_DIR + '{folder}/%Y/%m/%d/'
        path = self.date.strftime(templated_path.format(folder=self.folder))
        return VngHdfsTarget(path)

    def requires(self):
        yield _next_task(self, self.next_task)(**_params(self))


class HourlyUnDurationSparkTask(UnDurationSparkTask):
    date_hour = luigi.DateHourParameter(positional=False)

    def output(self):
        templated_path = DM_DIR + '{folder}/%Y/%m/%d/%H/'
        path = self.date_hour.strftime(templated_path.format(folder=self.folder))
        return VngHdfsTarget(path)


class UnDurationMultipleInputSparkTask(SparkTask):
    next_task = None

    def output(self):
        templated_path = DM_DIR + '{folder}/%Y/%m/%d/'
        path = self.date.strftime(templated_path.format(folder=self.folder))

        return VngHdfsTarget(path)

    @property
    @abc.abstractmethod
    def next_tasks(self):
        pass

    def requires(self):
        for next_task in self.next_tasks:
            yield _next_task(self, next_task)(**_params(self))


class UnDurationMultipleInputSparkTaskWithDecay(UnDurationMultipleInputSparkTask):
    def app_options(self):
        inputs = ','.join(self._inputs())
        return ['--input', inputs, '--output', 'hdfs://hadoopmaster22147:9000' + self.temp_output_path, '--decay',
                'true']


class HourlyUnDurationMultipleInputSparkTaskWithDecay(UnDurationMultipleInputSparkTaskWithDecay):
    date_hour = luigi.DateHourParameter(positional=False)

    def output(self):
        templated_path = DM_DIR + '{folder}/%Y/%m/%d/%H/'
        path = self.date_hour.strftime(templated_path.format(folder=self.folder))

        return VngHdfsTarget(path)


class UnionDecayTask(SparkTask):
    num_executors = 2
    executor_cores = 2
    executor_memory = '4G'

    @property
    @abc.abstractmethod
    def next_task_d00(self):
        pass

    def requires(self):
        params_dict = _params(self)
        yesterday = params_dict['date'] - dt.timedelta(days=1)

        yield _next_task(self, self.next_task_d00)(date=yesterday)
        yield _next_task(self, self.next_task)(date=params_dict['date'])

    def output(self):
        templated_path = DM_DIR + 'd00/{folder}/%Y/%m/%d/'

        path = self.dd_format(templated_path, folder=self.folder)
        return VngHdfsTarget(path)

    def app_options(self):
        inputs = ','.join(self._inputs())
        return ['--input', inputs, '--output', 'hdfs://hadoopmaster22147:9000' + self.temp_output_path, '--decay',
                'true']


class HourlySparkTask(SparkTask):
    date_hour = luigi.DateHourParameter(positional=False)

    def output(self):
        templated_path = DM_DIR + 'hourly/{}/%Y/%m/%d/%H/'
        path = self.date_hour.strftime(templated_path.format(self.folder))
        return VngHdfsTarget(path)

    def requires(self):
        yield _next_task(self, self.next_task)(date_hour=self.date_hour)


class ExternalLogsTask(luigi.ExternalTask, metaclass=abc.ABCMeta):
    date = luigi.DateParameter(positional=False)
    date_hour = None

    @property
    @abc.abstractmethod
    def folder(self):
        pass

    def output(self):
        templated_path = self.folder + '%Y/%m/%d/'
        path = self.date.strftime(templated_path)
        return luigi.contrib.hdfs.HdfsTarget(path)


class HourlyExternalLogsTask(ExternalLogsTask):
    date_hour = luigi.DateHourParameter(positional=False)
    date = None

    def output(self):
        templated_path = self.folder + '%Y/%m/%d/%H/'
        path = self.date_hour.strftime(templated_path)
        return luigi.contrib.hdfs.HdfsTarget(path)


class PythonTask(luigi.Task, DDParamsMixin, metaclass=abc.ABCMeta):
    date = luigi.DateParameter(positional=False)

    @property
    @abc.abstractmethod
    def folder(self):
        pass

    @property
    @abc.abstractmethod
    def next_task(self):
        pass

    @abc.abstractmethod
    def execute(self, path):
        pass

    def output(self):
        templated_path = self.folder + '/%Y/%m/%d/'

        path = self.dd_format(templated_path, folder=self.folder)
        return VngHdfsTarget(path)

    def run(self):
        with self.output().temporary_path() as temp_output_path:
            with _downloaded(self.input().path) as path:
                local_output_path = self.execute(path)
                _put(local_output_path, temp_output_path)

    def requires(self):
        return _next_task(self, self.next_task)(**_params(self))
