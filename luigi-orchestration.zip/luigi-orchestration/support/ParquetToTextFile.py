import luigi

import common.CommonTask as common
import datetime as dt

luigi.task.namespace(__name__)

DM_DIR = '/data/zte/rd/user_interest_v2/'


class RecentTransform(common.RecentHourlyGenerateTask):
    next_task = 'OutputTransform'

    def requires(self):
        for i in range(1, 730):
            last_hour = self.date_hour - dt.timedelta(hours=i)
            yield common._next_task(self, self.next_task)(date_hour=last_hour)

class OutputTransform(common.HourlyUnDurationSparkTask):
    date = None
    duration = None
    folder = "/data/zte/rd/user_interest/hourly/Product_Zoa"
    next_task = 'ExternalLogs'
    executor = "com.vng.zing.zudm_user_interest.transformation.OutputTransform"

class ExternalLogs(common.HourlyExternalLogsTask):
    folder = '/data/zte/rd/user_interest_v2/hourly/product/'
