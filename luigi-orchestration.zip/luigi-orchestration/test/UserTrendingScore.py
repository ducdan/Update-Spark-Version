import luigi

import common.CommonTask as common
import datetime as dt

luigi.task.namespace(__name__)

DM_DIR = '/data/zte/rd/user_interest_v2/'


class RecentPredict(common.RecentHourlyGenerateTask):
    next_task = 'OutputTransform'

class OutputTransform(common.HourlyUnDurationSparkTask):
    folder = "testing_only/trending/text_file"
    next_task = 'Union'
    executor = "com.vng.zing.zudm_user_interest.transformation.OutputTransform"


class Union(common.HourlyUnDurationMultipleInputSparkTaskWithDecay):
    num_executors = 2
    executor_cores = 2
    executor_memory = '8G'

    folder = "testing_only/trending/parquet"
    next_tasks = ['D90DemographicLogs', 'ExternalLogs']
    executor = 'com.vng.zing.zudm_user_interest.union.UserTrendingScore'

class ExternalLogs(common.HourlyExternalLogsTask):
    date = luigi.DateParameter(positional=False)
    duration = luigi.EnumParameter(enum=common.Duration)
    folder = DM_DIR + 'recommender/product/tf/Product/'

class D90DemographicLogs(common.ExternalLogsTask):
    folder = DM_DIR + "d90/demographic_group/"
    duration = luigi.EnumParameter(enum=common.Duration)
    date_hour = luigi.DateHourParameter(positional=False)
