import luigi
import datetime as dt
import common.CommonTask as common

luigi.task.namespace(__name__)

class RecentUnions(common.RecentGenerateTask):
    last_day = 2
    duration = common.Duration.d90
    next_task = 'TransformToGroup'

class TransformToGroup(common.RootSparkTask):
    executor = "com.vng.zing.zudm_user_interest.transformation.DemographicGroup"
    folder = "demographic_group"
    next_task = 'DailyUnion'
class DailyUnion(common.SparkTask):
    executor = "com.vng.zing.zudm_user_interest.union.DailyDemographicUnion"
    folder = "demographic"
    next_task = 'HourlyExtract'

    num_executors = 4
    executor_cores = 4
    executor_memory = '16G'


class HourlyExtract(common.HourlySparkTask):
    executor = "com.vng.zing.zudm_user_interest.transformation.HourlyDemographicExtract"
    folder = "demographic"
    next_task = 'ExternalLogs'

class ExternalLogs(common.HourlyExternalLogsTask):
    folder = '/data/zte/rd/intermediate_data/ZOA_TRACKING/'

    # def complete(self):
    #     if self.date_hour + dt.timedelta(hours=1) < dt.datetime.today():
    #         return True
    #     return False
