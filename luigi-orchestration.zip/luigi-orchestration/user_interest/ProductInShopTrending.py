import luigi

import common.CommonTask as common
import datetime as dt

luigi.task.namespace(__name__)

DM_DIR = '/data/zte/rd/user_interest_v2/'


class RecentPredict(common.RecentHourlyGenerateTask):
    next_task = 'PushDB'


class PushDB(common.HourlyUploadTask):
    folder = DM_DIR + 'output/product/ProductInShop/trending'
    next_task = 'OutputTransform'
    class_path = 'com.vng.zing.zudm_user_interest.app.ProductSuggestionWrite'
    db_key = 'product_trending_in_shop'
    resource = {"upload_to_product_trending_db_lock": 1}


class OutputTransform(common.HourlyUnDurationSparkTask):
    folder = "output/product/ProductInShop/trending"
    next_task = 'Trending'
    executor = "com.vng.zing.zudm_user_interest.transformation.OutputTransform"


class Trending(common.HourlyUnDurationMultipleInputSparkTaskWithDecay):
    num_executors = 2
    executor_cores = 2
    executor_memory = '8G'

    folder = "recommender/product/tf/ProductInShop"
    next_tasks = ['D90DemographicLogs', 'ProductPurchasing']
    executor = 'com.vng.zing.zudm_user_interest.recommendation.ProductInShopTrending'


class ProductPurchasing(common.HourlyExternalLogsTask):
    date = luigi.DateParameter(positional=False)
    duration = luigi.EnumParameter(enum=common.Duration)

    folder = DM_DIR + "recommender/product/ProductPurchasing/"


class D90DemographicLogs(common.ExternalLogsTask):
    folder = DM_DIR + "d90/demographic_group/"
    duration = luigi.EnumParameter(enum=common.Duration)
    date_hour = luigi.DateHourParameter(positional=False)
