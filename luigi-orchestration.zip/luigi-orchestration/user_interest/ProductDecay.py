import luigi
import datetime as dt
import common.CommonTask as common

luigi.task.namespace(__name__)
DM_DIR = '/data/zte/rd/user_interest_v2/'

class RecentUnions(common.RecentGenerateTask):
    last_day = 7
    next_task = 'PushDB'

class PushDB(common.UploadTask):
    folder = DM_DIR + 'd00/product_text'
    next_task = 'OutputTransform'
    class_path = 'com.vng.zing.zudm_user_interest.app.ProductSuggestionWrite'
    db_key = 'product_decay'
    def run(self):
        pass


class OutputTransform(common.UnDurationSparkTask):
    folder = "d00/product_text"
    next_task = 'UnionDecay'
    executor = "com.vng.zing.zudm_user_interest.transformation.OutputTransform"

class UnionDecay(common.UnionDecayTask):
    executor = "com.vng.zing.zudm_user_interest.union.ProductDecay"
    folder = "product"
    next_task = 'D01ExternalLogs'
    next_task_d00 = 'D00ExternalLogs'

class D01ExternalLogs(common.ExternalLogsTask):
    folder = '/data/zte/rd/user_interest_v2/d01/product/'

class D00ExternalLogs(common.ExternalLogsTask):
    folder = '/data/zte/rd/user_interest_v2/d00/product/'
