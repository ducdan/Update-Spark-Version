import luigi

import common.CommonTask as common
import datetime as dt

luigi.task.namespace(__name__)

DM_DIR = '/data/zte/rd/user_interest_v2/'


class RecentPredict(common.RecentHourlyGenerateTask):
    next_task = 'PushDB'


class PushDB(common.HourlyUploadTask):
    folder = DM_DIR + 'output/oa/tfidf'
    next_task = 'FilterOutPut'
    class_path = 'com.vng.zing.zudm_user_interest.app.ZOASuggestionWrite'
    db_key = 'zoa_tfidf'
    resource = {"upload_to_tfidf_db_lock": 1}


class FilterOutPut(common.HourlyFiterBadItems):
    folder = 'output/oa/tfidf'
    db_key = 'zoa'
    class_path = 'com.vng.zing.zudm_user_interest.validation.Validator'
    next_task = 'OutputTransform'


class OutputTransform(common.HourlyUnDurationSparkTask):
    folder = "recommender/oa/output-text/tfidf"
    next_task = 'FilterOANonActive'
    executor = "com.vng.zing.zudm_user_interest.transformation.OutputTransform"


class FilterOANonActive(common.HourlyUnDurationMultipleInputSparkTaskWithDecay):
    folder = "recommender/oa/tfidf_active"
    next_tasks = ['TfIdf', 'D30OAActiveLogs']
    executor = 'com.vng.zing.zudm_user_interest.union.FilterOANonActive'

class TfIdf(common.HourlyUnDurationMultipleInputSparkTaskWithDecay):
    num_executors = 2
    executor_cores = 2
    executor_memory = '8G'

    folder = "recommender/oa/TfIdf"
    next_tasks = ['D90DemographicLogs', 'OAFollow']
    executor = 'com.vng.zing.zudm_user_interest.recommendation.OATfIdf'


class OAFollow(common.HourlyExternalLogsTask):
    folder = DM_DIR + "recommender/oa/follow/"
    duration = luigi.EnumParameter(enum=common.Duration)
    date = luigi.DateParameter(positional=False)


class D90DemographicLogs(common.ExternalLogsTask):
    folder = DM_DIR + "d90/demographic_group/"
    duration = luigi.EnumParameter(enum=common.Duration)
    date_hour = luigi.DateHourParameter(positional=False)

class D30OAActiveLogs(common.ExternalLogsTask):
    folder = '/data/zte/rd/user_interest_v2/d30/oa/'
    duration = luigi.EnumParameter(enum=common.Duration)
    date_hour = luigi.DateHourParameter(positional=False)
