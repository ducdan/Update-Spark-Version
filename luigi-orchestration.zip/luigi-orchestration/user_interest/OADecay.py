import luigi
import datetime as dt
import common.CommonTask as common

luigi.task.namespace(__name__)
DM_DIR = '/data/zte/rd/user_interest_v2/'

class RecentUnions(common.RecentGenerateTask):
    last_day = 2
    next_task = 'PushDB'

class PushDB(common.UploadTask):
    folder = DM_DIR + 'recommender/oa/normalize_text'
    next_task = 'OutputTransform'
    class_path = 'com.vng.zing.zudm_user_interest.app.ZOASuggestionWrite'
    db_key = 'oa_decay'


class OutputTransform(common.UnDurationSparkTask):
    folder = "recommender/oa/normalize_text"
    next_task = 'Normalize'
    executor = "com.vng.zing.zudm_user_interest.transformation.OutputTransform"


class Normalize(common.UnDurationSparkTask):
    folder = "recommender/oa/normalize"
    next_task = 'UnionDecay'
    executor = 'com.vng.zing.zudm_user_interest.transformation.OANormalization'

class UnionDecay(common.UnionDecayTask):
    executor = "com.vng.zing.zudm_user_interest.union.OADecay"
    folder = "oa"
    next_task = 'D01ExternalLogs'
    next_task_d00 = 'D00ExternalLogs'

class D01ExternalLogs(common.ExternalLogsTask):
    folder = '/data/zte/rd/user_interest_v2/d01/oa/'

class D00ExternalLogs(common.ExternalLogsTask):
    folder = '/data/zte/rd/user_interest_v2/d00/oa/'
