import luigi

import common.CommonTask as common

luigi.task.namespace(__name__)

DM_DIR = '/data/zte/rd/user_interest_v2/'


class RecentPredict(common.RecentGenerateTask):
    last_day = 2
    next_task = 'PushDB'


class PushDB(common.UploadTask):
    folder = DM_DIR + 'recommender/product/ALSPredict'
    next_task = 'ALSPredict'
    class_path = 'com.vng.zing.zudm_user_interest.app.ProductSuggestionWrite'
    db_key = 'product_als'


class ALSPredict(common.UnDurationMultipleInputSparkTask):
    num_executors = 4
    executor_cores = 4
    executor_memory = '16G'
    driver_memory = '4G'

    folder = "recommender/product/ALSPredict"
    next_tasks = ['ALSTraining', 'UserExtract', 'ItemExtract']
    executor = 'com.vng.zing.zudm_user_interest.recommendation.ALSProductPredict'


class UserExtract(common.UnDurationSparkTask):
    folder = 'recommender/product/users'
    next_task = 'ALSTraining'
    executor = 'com.vng.zing.zudm_user_interest.recommendation.UserExtract'


class ALSTraining(common.UnDurationSparkTask):
    num_executors = 4
    executor_cores = 4
    executor_memory = '16G'

    folder = 'recommender/product/ALSModel'
    next_task = 'NormalizeRPScore'
    executor = 'com.vng.zing.zudm_user_interest.recommendation.ProductTraining'


class NormalizeRPScore(common.UnDurationSparkTask):
    folder = "recommender/product/normalize_rp_score"
    next_task = 'D00Logs'
    executor = 'com.vng.zing.zudm_user_interest.transformation.RPScore'


class D00Logs(common.ExternalLogsTask):
    folder = '/data/zte/rd/user_interest_v2/d00/product/'
    duration = luigi.EnumParameter(enum=common.Duration)


class ItemExtract(common.UnDurationSparkTask):
    folder = 'recommender/product/items'
    next_task = 'ProductA7'
    executor = 'com.vng.zing.zudm_user_interest.recommendation.ProductA7'


class ProductA7(common.ExternalLogsTask):
    folder = '/data/zte/rd/user_interest_v2/d07/product/'
    duration = luigi.EnumParameter(enum=common.Duration)

# class PushDB(common.UploadTask):
#     folder = DM_DIR + 'recommender/oa/ALSPredict'
#     next_task = 'ALSPredict'
#     class_path = 'com.vng.zing.zudm_user_interest.app.ZOASuggestionWrite'
#     db_key = 'zoa_als2_'
#
#
# class ALSPredict(common.UnDurationMultipleInputSparkTask):
#     num_executors = 4
#     executor_cores = 4
#     executor_memory = '16G'
#     driver_memory = '4G'
#
#     folder = "recommender/oa/ALSPredict"
#     next_tasks = ['ALSTraining', 'UserExtract', 'A7OALogs']
#     executor = 'com.vng.zing.zudm_user_interest.recommendation.ZoaId_ALSPredictForA7Data'
#
#
# class UserExtract(common.UnDurationSparkTask):
#     folder = 'recommender/oa/users'
#     next_task = 'ALSTraining'
#     executor = 'com.vng.zing.zudm_user_interest.recommendation.ExtractUidFromALSModel'
#
#

# class ItemExtract(common.UnDurationSparkTask):
#     folder = 'recommender/oa/items'
#     next_task = 'A7OALogs'
#     executor = 'com.vng.zing.zudm_user_interest.recommendation.OAForA7'
#
#
# class OANormalization(common.UnDurationSparkTask):
#     folder = "recommender/oa/normalization"
#     next_task = 'D90OALogs'
#     executor = "com.vng.zing.zudm_user_interest.transformation.OANormalization"
#
#
# class D90OALogs(common.ExternalLogsTask):
#     folder = DM_DIR + "d30/oa/"
#     duration = luigi.EnumParameter(enum=common.Duration)
#
# class A7OALogs(common.ExternalLogsTask):
#     folder = '/data/zte/rd/user_interest/recommender/ValidZoaA7/'
#     duration = luigi.EnumParameter(enum=common.Duration)
