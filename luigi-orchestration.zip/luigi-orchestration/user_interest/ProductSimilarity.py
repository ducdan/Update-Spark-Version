import luigi

import common.CommonTask as common
import datetime as dt

luigi.task.namespace(__name__)

DM_DIR = '/data/zte/rd/user_interest_v2/'


class RecentPredict(common.RecentGenerateTask):
    next_task = 'PushDB'
    last_day = 2

class PushDB(common.UploadTask):
    folder = DM_DIR + 'output/product/Product/similarity'
    next_task = 'OutputTransform'
    class_path = 'com.vng.zing.zudm_user_interest.app.ProductSuggestionWrite'
    db_key = 'product_similarity'
    resource = {"upload_to_product_similarity_db_lock": 1}


class OutputTransform(common.UnDurationSparkTask):
    folder = "output/product/Product/similarity"
    next_task = 'ProductSimilarity'
    executor = "com.vng.zing.zudm_user_interest.transformation.OutputTransform"



class ProductSimilarity(common.UnDurationSparkTask):
    folder = "recommender/product/similarity/Product"
    next_task = 'D00Logs'
    executor = 'com.vng.zing.zudm_user_interest.recommendation.ProductSimilarity'


class D00Logs(common.ExternalLogsTask):
    folder = '/data/zte/rd/user_interest_v2/d00/product/'
    duration = luigi.EnumParameter(enum=common.Duration)
