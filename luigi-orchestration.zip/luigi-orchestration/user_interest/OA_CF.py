import luigi

import common.CommonTask as common

luigi.task.namespace(__name__)

DM_DIR = '/data/zte/rd/user_interest_v2/'


class RecentPredict(common.RecentGenerateTask):
    last_day = 2
    next_task = 'PushDB'


class PushDB(common.UploadTask):
    folder = DM_DIR + 'recommender/oa/ALSPredict'
    next_task = 'ALSPredict'
    class_path = 'com.vng.zing.zudm_user_interest.app.ZOASuggestionWrite'
    db_key = 'oa_als'

# class FilterOutPut(common.FiterBadItems):
#     folder = 'output/oa/ALSResult'
#     db_key = 'zoa'
#     class_path = 'com.vng.zing.zudm_user_interest.validation.Validator'
#     next_task = 'ALSPredict'

class ALSPredict(common.UnDurationMultipleInputSparkTask):
    num_executors = 4
    executor_cores = 4
    executor_memory = '16G'
    driver_memory = '4G'

    folder = "recommender/oa/ALSPredict"
    next_tasks = ['ALSTraining', 'UserExtract', 'ItemExtract']
    executor = 'com.vng.zing.zudm_user_interest.recommendation.ALSOAPredict'


class UserItemExtract(common.UnDurationMultipleInputSparkTask):
    folder = 'recommender/oa/user_items'
    next_tasks = ['ALSTraining', 'UserExtract', 'ItemExtract']
    executor = 'com.vng.zing.zudm_user_interest.recommendation.OAUserItemExtract'


class ALSTraining(common.UnDurationSparkTask):
    num_executors = 4
    executor_cores = 4
    executor_memory = '16G'

    folder = 'recommender/oa/ALSModel'
    next_task = 'NormalizeLogs'
    executor = 'com.vng.zing.zudm_user_interest.recommendation.OATraining'

class NormalizeLogs(common.ExternalLogsTask):
    folder = DM_DIR + "recommender/oa/normalize/"
    duration = luigi.EnumParameter(enum=common.Duration)

class ItemExtract(common.UnDurationSparkTask):
    folder = 'recommender/oa/items'
    next_task = 'OAA7'
    executor = 'com.vng.zing.zudm_user_interest.recommendation.OAA7'


class DemographicLogs(common.ExternalLogsTask):
    folder = '/data/zte/rd/user_interest_v2/d90/demographic_group/'
    duration = luigi.EnumParameter(enum=common.Duration)
class TrendingLogs(common.ExternalLogsTask):
    folder = '/data/zte/rd/user_interest_v2/d07/oa/'
    duration = luigi.EnumParameter(enum=common.Duration)
