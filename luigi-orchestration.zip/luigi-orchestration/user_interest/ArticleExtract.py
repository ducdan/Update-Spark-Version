import luigi
import datetime as dt
import common.CommonTask as common

luigi.task.namespace(__name__)

class RecentUnions(common.RecentGenerateTask):
    last_day = 60

    next_task = 'DailyUnion'


class DailyUnion(common.SparkTask):
    executor = "com.vng.zing.zudm_user_interest.union.DailyArticleUnion"
    folder = "article"
    next_task = 'HourlyExtract'

class HourlyExtract(common.HourlySparkTask):
    executor = "com.vng.zing.zudm_user_interest.transformation.HourlyArticleExtract"
    folder = "article"
    next_task = 'ExternalLogs'

class ExternalLogs(common.HourlyExternalLogsTask):
    folder = '/data/zte/rd/intermediate_data/ZOA_TRACKING/'

    # def complete(self):
    #     if self.date_hour + dt.timedelta(hours=1) < dt.datetime.today():
    #         return True
    #     return False
