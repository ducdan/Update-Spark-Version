import luigi

import common.CommonTask as common
import datetime as dt

luigi.task.namespace(__name__)

DM_DIR = '/data/zte/rd/user_interest_v2/'


class RecentPredict(common.RecentHourlyGenerateTask):
    next_task = 'PushDB'


class PushDB(common.HourlyUploadTask):
    folder = DM_DIR + 'output/product/StoreCate/trending'
    next_task = 'OutputTransform'
    class_path = 'com.vng.zing.zudm_user_interest.app.ProductSuggestionWrite'
    db_key = 'product_trending_store_cate'
    resource = {"upload_to_product_trending_db_lock": 1}


class OutputTransform(common.HourlyUnDurationSparkTask):
    folder = "output/product/StoreCate/trending"
    next_task = 'Trending'
    executor = "com.vng.zing.zudm_user_interest.transformation.OutputTransform"


class Trending(common.HourlyUnDurationMultipleInputSparkTaskWithDecay):
    num_executors = 2
    executor_cores = 2
    executor_memory = '8G'

    folder = "recommender/product/tf/StoreCate"
    next_tasks = ['D90DemographicLogs', 'ProductPurchasing']
    executor = 'com.vng.zing.zudm_user_interest.recommendation.StoreCateTrending'


class ProductPurchasing(common.SparkTask):
    date_hour = luigi.DateHourParameter(positional=False)

    hour_back = 168

    folder = "recommender/product/ProductPurchasing"
    next_task = 'ExternalLogs'
    executor = "com.vng.zing.zudm_user_interest.transformation.ProductPurchasing"

    def requires(self):
        for i in range(self.hour_back):
            last_hour = self.date_hour - dt.timedelta(hours=i)
            yield common._next_task(self, self.next_task)(date_hour=last_hour)

    def output(self):
        templated_path = DM_DIR + '{folder}/%Y/%m/%d/%H/'
        path = self.date_hour.strftime(templated_path.format(folder=self.folder))
        return common.VngHdfsTarget(path)


class ExternalLogs(common.HourlyExternalLogsTask):
    folder = '/data/zte/rd/user_interest_v2/hourly/product/'


class D90DemographicLogs(common.ExternalLogsTask):
    folder = DM_DIR + "d90/demographic_group/"
    duration = luigi.EnumParameter(enum=common.Duration)
    date_hour = luigi.DateHourParameter(positional=False)
