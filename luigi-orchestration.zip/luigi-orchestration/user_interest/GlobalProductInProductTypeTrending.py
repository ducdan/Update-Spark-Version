import luigi

import common.CommonTask as common
import datetime as dt

luigi.task.namespace(__name__)

DM_DIR = '/data/zte/rd/user_interest_v2/'


class RecentPredict(common.RecentHourlyGenerateTask):
    next_task = 'PushDB'


class PushDB(common.HourlyUploadTask):
    folder = DM_DIR + 'output/product/GlobalProductInProductType/trending'
    next_task = 'OutputTransform'
    class_path = 'com.vng.zing.zudm_user_interest.app.ProductSuggestionWrite'
    db_key = 'global_product_trending_in_product_type'
    resource = {"upload_to_product_trending_db_lock": 1}


class OutputTransform(common.HourlyUnDurationSparkTask):
    folder = "output/product/GlobalProductInProductType/trending"
    next_task = 'Trending'
    executor = "com.vng.zing.zudm_user_interest.transformation.OutputTransform"


class Trending(common.HourlyUnDurationSparkTask):
    folder = "recommender/product/tf/GlobalProductInProductType"
    next_task = 'ProductPurchasing'
    executor = 'com.vng.zing.zudm_user_interest.recommendation.GlobalProductInProductTypeTrending'


class ProductPurchasing(common.HourlyExternalLogsTask):
    date = luigi.DateParameter(positional=False)
    duration = luigi.EnumParameter(enum=common.Duration)

    folder = DM_DIR + "recommender/product/ProductPurchasing/"
