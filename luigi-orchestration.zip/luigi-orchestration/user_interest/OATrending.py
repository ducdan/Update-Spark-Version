import luigi

import common.CommonTask as common
import datetime as dt

luigi.task.namespace(__name__)

DM_DIR = '/data/zte/rd/user_interest_v2/'


class RecentPredict(common.RecentHourlyGenerateTask):
    next_task = 'PushDB'


class PushDB(common.HourlyUploadTask):
    folder = DM_DIR + 'output/oa/trending'
    next_task = 'FilterOutPut'
    class_path = 'com.vng.zing.zudm_user_interest.app.ZOASuggestionWrite'
    db_key = 'zoa_trending'
    resource = {"upload_to_trending_db_lock": 1}

class FilterOutPut(common.HourlyFiterBadItems):
    folder = 'output/oa/trending'
    db_key = 'zoa'
    class_path = 'com.vng.zing.zudm_user_interest.validation.Validator'
    next_task = 'OutputTransform'


class OutputTransform(common.HourlyUnDurationSparkTask):
    folder = "recommender/oa/output-text/trending"
    next_task = 'FilterOANonActive'
    executor = "com.vng.zing.zudm_user_interest.transformation.OutputTransform"


class FilterOANonActive(common.HourlyUnDurationMultipleInputSparkTaskWithDecay):
    folder = "recommender/oa/tf_active"
    next_tasks = ['Trending', 'D30OAActiveLogs']
    executor = 'com.vng.zing.zudm_user_interest.union.FilterOANonActive'

class Trending(common.HourlyUnDurationMultipleInputSparkTaskWithDecay):
    num_executors = 2
    executor_cores = 2
    executor_memory = '8G'

    folder = "recommender/oa/tf"
    next_tasks = ['D90DemographicLogs', 'OAFollow']
    executor = 'com.vng.zing.zudm_user_interest.recommendation.OATrending'


class OAFollow(common.HourlySparkTask):
    hour_back = 24

    folder = "recommender/oa/follow"
    next_task = 'ExternalLogs'
    executor = "com.vng.zing.zudm_user_interest.transformation.OAFollow"

    def requires(self):
        for i in range(self.hour_back):
            last_hour = self.date_hour - dt.timedelta(hours=i)
            yield common._next_task(self, self.next_task)(date_hour=last_hour)

    def output(self):
        templated_path = DM_DIR + '{folder}/%Y/%m/%d/%H/'
        path = self.date_hour.strftime(templated_path.format(folder=self.folder))
        return common.VngHdfsTarget(path)


class ExternalLogs(common.HourlyExternalLogsTask):
    folder = '/data/zte/rd/user_interest_v2/hourly/oa/'


class D90DemographicLogs(common.ExternalLogsTask):
    folder = DM_DIR + "d90/demographic_group/"
    duration = luigi.EnumParameter(enum=common.Duration)
    date_hour = luigi.DateHourParameter(positional=False)

class D30OAActiveLogs(common.ExternalLogsTask):
    folder = '/data/zte/rd/user_interest_v2/d30/oa/'
    duration = luigi.EnumParameter(enum=common.Duration)
    date_hour = luigi.DateHourParameter(positional=False)

