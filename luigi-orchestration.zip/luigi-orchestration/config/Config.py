import luigi
from plumbum import local


class SparkConfig(luigi.contrib.spark.SparkSubmitTask):
    """TODO:
        sonpvh & danhd: Oct, 16, 2017
        seperate Sparkconfig out of  sparksubmit
    """
    queue = 'low'
    num_executors=2
    executor_cores=2
    executor_memory = '2G'
    deploy_mode = 'cluster'
    master = 'yarn'
    spark_submit = '/zserver/zte/spark-2.2.0-bin-hadoop2.4/bin/spark-submit'
    app = '/zserver/zte/apps/zudm_user_interest_v2/spark-transforms/' \
          'user_interest_v2-assembly-1.1-SNAPSHOT.jar'


class JavaConfig(luigi.Task):
    jar_file = '/zserver/zte/apps/zudm_user_interest_v2/dist/' \
               'db-upload.jar'

    app_name = 'zudm_user_interest'
    env = 'production'
    config_dir = '/zserver/zte/apps/zudm_user_interest_v2/conf'
    class_path = 'com.vng.zing.zudm_user_interest.app.AtomicallyWrite'

    @property
    def class_path(self):
        pass

    @property
    def app(self):
        java = local.get('/zserver/java/jdk1.8.0_11-x64/bin/java',
                         'java',
                         )
        return java[
            '-enableassertions',
            '-Dzappname=' + self.app_name,
            '-Dzappprof=' + self.env,
            '-Dzconfdir=' + self.config_dir,
            '-Djzcommonx.version=LATEST', ## this is for profiler
            '-Dzicachex.version=LATEST', ## this is for profiler
            '-classpath',
            self.jar_file,
        ]
