# """
# This is one of those "bad" modules that hopefully goes away one day. It
# basically contains code that should be somewhere else at the moment.
# """
# import abc
# import datetime as dt
# import functools
# # import common.CommonTask as common
# import logging
# import os.path
# import random
# import tempfile
# from contextlib import contextmanager
# from enum import Enum
# 
# import luigi
# import luigi.contrib.hdfs
# import luigi.contrib.spark
# import luigi.task
# import luigi.task_register
# from plumbum import local
# from plumbum.cmd import grep
# 
# import common.CommonTask as common
# 
# logger = logging.getLogger(__name__)
# luigi.task.namespace(__name__)
# 
# DM_DIR = '/data/zte/rd/user_interest_v2/'
# 
# 
# def _hadoopcli_client():
#     return luigi.contrib.hdfs.HdfsClient()
# 
# 
# def _next_task(task, cls_name):
#     new_family = task.get_task_namespace() + "." + cls_name
#     return luigi.task_register.Register.get_task_cls(new_family)
# 
# 
# def _params(task):
#     return {k: getattr(task, k) for (k, _) in task.get_params()}
# 
# 
# class Duration(Enum):
#     d00 = 1
# 
#     def calc_priority(self):
#         return 6 - self.value
# 
#     def dependencies(self, date):
#         yield self, date
# 
# 
# class DDParamsMixin(object):
#     date = luigi.DateParameter(positional=False)
# 
#     #     duration = luigi.EnumParameter(enum=Duration)
# 
#     def dd_format(self, templated_string, *args, **kwargs):
#         return self.date.strftime(templated_string.format(*args, **kwargs))
# 
# 
# class VngHdfsTarget(luigi.contrib.hdfs.HdfsTarget):
#     def temporary_path(target):
#         class Manager(object):
#             def __enter__(self):
#                 path = target.path.rstrip('/')
#                 num = random.randrange(0, 1e10)
#                 self.temp_path = path + '-luigi-tmp-{:010}'.format(num)
#                 return self.temp_path
# 
#             def __exit__(self, exc_type, exc_value, traceback):
#                 if exc_type is None:
#                     # There were no exceptions
#                     target.fs.rename_dont_move(self.temp_path, target.path)
#                 return False
# 
#         return Manager()
# 
# 
# class RecentPredictTask(luigi.task.WrapperTask):
#     date = luigi.DateParameter(default=dt.date.today(), significant=False)
# 
#     @abc.abstractmethod
#     def next_task(self):
#         pass
# 
#     @property
#     @abc.abstractmethod
#     def lastDay(self):
#         pass
# 
#     def requires(self):
#         dates = list()
#         for i in range(self.lastDay):
#             yesterday = self.date - dt.timedelta(days=i)
#             dates.append(yesterday)
#         params_dict = _params(self)
#         del params_dict['date']
#         for date in dates:
#             yield _next_task(self, self.next_task)(date=date, **params_dict)
# 
# class UploadTask(luigi.Task, DDParamsMixin, metaclass=abc.ABCMeta):
#     jar_file = '/zserver/apps/zudm_zingmp3_suggestion/dist/' \
#                'db-upload.jar'
# 
#     def process_resources(self):
#         resources = {"upload_to_db_lock": 1}
#         resources.update(self.resources)
#         return resources
# 
#     @property
#     def db_key_infix(self):
#         return self.folder.replace('/', '_')
# 
#     @property
#     def db_key(self):
#         return self.dd_format("user_interest"
#                               "{db_key_infix}__"
#                               "{duration_name}",
#                               db_key_infix=self.db_key_infix)
# 
#     @property
#     @abc.abstractmethod
#     def folder(self):
#         pass
# 
#     @property
#     @abc.abstractmethod
#     def next_task(self):
#         pass
# 
#     @property
#     def app(self):
#         java = local.get('/zserver/java/jdk1.8.0_11-x64/bin/java',
#                          'java',
#                          )
#         return java[
#             '-enableassertions',
#             '-Dzappname=zudm_zingmp3_suggestion',
#             '-Dzappprof=production',
#             '-Dzconfdir=/zserver/apps/zudm_zingmp3_suggestion/conf',
#             '-classpath',
#             self.jar_file,
#         ]
# 
#     def output(self):
#         templated_path = DM_DIR + '{folder}/%Y/%m/%d/' \
#                                   'UPLOAD_DONE.marker_file'
#         return VngHdfsTarget(self.dd_format(templated_path,
#                                             folder=self.folder))
# 
#     @contextmanager
#     def _downloaded_uids(self):
#         client = _hadoopcli_client()
#         tempfile.tempdir = "/data/zte/zmining/user_interest/"
#         with tempfile.TemporaryDirectory(suffix='user_interest') as td_path:
#             tmppath = os.path.join(td_path, 'from_hadoop')
#             client.get(self.input().path, tmppath)
#             yield tmppath
# 
#     def _touchz(self):
#         _hadoopcli_client().touchz(self.output().path)
# 
#     def ingest_users_to_db(self):
#         """
#         Ingest users to db and return number of users ingested (as string!)
#         """
#         with self._downloaded_uids() as uids_path:
#             program = self.app[
#                 'com.vng.zing.zudm_user_interest.app.ProductSuggestionWrite',
#                 uids_path
#             ]
#             kw = 'NUM_ENTRIES: '
#             return (program | grep[kw])()[len(kw):].strip()
# 
#     def run(self):
#         self.ingest_users_to_db()
#         self._touchz()
# 
#     def requires(self):
#         return _next_task(self, self.next_task)(**_params(self))
# 
# 
# class ALSPredictD90JoiningTask(CASparkSubmitTask, DDParamsMixin, metaclass=abc.ABCMeta):
#     date = luigi.DateParameter(positional=False)
# 
#     @property
#     @abc.abstractmethod
#     def executor(self):
#         pass
# 
#     @property
#     def entry_class(self):
#         return ('com.vng.zing.zudm_user_interest.profile.'
#                 + self.executor)
# 
#     def output(self):
#         templated_path = DM_DIR + 'recommender/{folder}/%Y/%m/%d/'
# 
#         path = self.dd_format(templated_path, folder=self.folder)
#         return VngHdfsTarget(path)
# 
#     def requires(self):
#         params_dict = _params(self)
#         yield _next_task(self, 'DemoLogs')(**params_dict)
#         yield _next_task(self, 'ALSPredict')(**params_dict)
# 
#     def app_options(self):
#         inputs = ','.join(self._inputs())
#         return ['--input', inputs, '--output', self.temp_output_path, '--decay', "true"]
# 
# 
# class PredictTask(CASparkSubmitTask, DDParamsMixin, metaclass=abc.ABCMeta):
#     date = luigi.DateParameter(positional=False)
# 
#     @property
#     def entry_class(self):
#         return ('com.vng.zing.zudm_zingmp3_suggestion.recommendation.'
#                 + self.executor)
# 
#     @property
#     @abc.abstractmethod
#     def folder(self):
#         pass
# 
#     @property
#     @abc.abstractmethod
#     def executor(self):
#         pass
# 
#     @property
#     @abc.abstractmethod
#     def next_task1(self):
#         pass
# 
#     @property
#     @abc.abstractmethod
#     def next_task2(self):
#         pass
# 
#     @property
#     @abc.abstractmethod
#     def next_task3(self):
#         pass
# 
#     def output(self):
#         templated_path = DM_DIR + '{folder}/%Y/%m/%d/'
#         path = self.dd_format(templated_path, folder=self.folder)
#         return VngHdfsTarget(path)
# 
#     def requires(self):
#         yield _next_task(self, self.next_task1)(**_params(self))
#         yield _next_task(self, self.next_task2)(**_params(self))
#         yield _next_task(self, self.next_task3)(**_params(self))
# 
# 
# class ExtractUidInALSModelTask(CASparkSubmitTask, DDParamsMixin, metaclass=abc.ABCMeta):
#     date = luigi.DateParameter(positional=False)
# 
#     @property
#     def entry_class(self):
#         return ('com.vng.zing.zudm_zingmp3_suggestion.recommendation.'
#                 + self.executor)
# 
#     @property
#     @abc.abstractmethod
#     def folder(self):
#         pass
# 
#     @property
#     @abc.abstractmethod
#     def executor(self):
#         pass
# 
#     @property
#     @abc.abstractmethod
#     def next_task(self):
#         pass
# 
#     def output(self):
#         templated_path = DM_DIR + '{folder}/%Y/%m/%d/'
#         path = self.dd_format(templated_path, folder=self.folder)
#         return VngHdfsTarget(path)
# 
#     def requires(self):
#         yield _next_task(self, self.next_task)(**_params(self))
# 
# 
# class ALSTrainingTask(CASparkSubmitTask, DDParamsMixin, metaclass=abc.ABCMeta):
#     date = luigi.DateParameter(positional=False)
# 
#     @property
#     def entry_class(self):
#         return ('com.vng.zing.zudm_zingmp3_suggestion.recommendation.'
#                 + self.executor)
# 
#     @property
#     @abc.abstractmethod
#     def folder(self):
#         pass
# 
#     @property
#     @abc.abstractmethod
#     def executor(self):
#         pass
# 
#     @property
#     @abc.abstractmethod
#     def next_task(self):
#         pass
# 
#     def output(self):
#         templated_path = DM_DIR + '{folder}/%Y/%m/%d/'
#         path = self.dd_format(templated_path, folder=self.folder)
#         return VngHdfsTarget(path)
# 
#     def requires(self):
#         params_dict = _params(self)
#         yield _next_task(self, self.next_task)(**_params(self))
# 
# 
# class NormalizeTask(luigi.Task, DDParamsMixin, metaclass=abc.ABCMeta):
#     date = luigi.DateParameter(positional=False)
# 
#     @property
#     @abc.abstractmethod
#     def columns(self):
#         pass
# 
#     @property
#     @abc.abstractmethod
#     def folder(self):
#         pass
# 
#     @property
#     @abc.abstractmethod
#     def next_task(self):
#         pass
# 
#     @abc.abstractmethod
#     def normalize(self, path):
#         pass
# 
#     def output(self):
#         templated_path = DM_DIR + '{folder}/%Y/%m/%d/'
# 
#         path = self.dd_format(templated_path, folder=self.folder)
#         return VngHdfsTarget(path)
# 
#     @contextmanager
#     def _downloaded_uids(self):
#         client = _hadoopcli_client()
#         tempfile.tempdir = "/data/zte/zmining/user_interest/"
#         with tempfile.TemporaryDirectory(suffix='user_interest') as td_path:
#             tmppath = os.path.join(td_path, 'from_hadoop')
#             client.get(self.input().path, tmppath)
#             yield tmppath
# 
#     def _put(self):
#         _hadoopcli_client().mkdir(self.temp_output_path)
#         _hadoopcli_client().put(self.tmpfile, self.temp_output_path)
# 
#     def do_normalize_job(self):
#         with self._downloaded_uids() as uids_path:
#             data = self.normalize(uids_path)
# 
#             tempfile.tempdir = "/data/zte/zmining/user_interest/"
#             with tempfile.TemporaryDirectory(suffix='user_interest') as td_path:
#                 tmppath = os.path.join(td_path, 'local')
#                 if not os.path.exists(tmppath):
#                     os.makedirs(tmppath)
#                 self.tmpfile = os.path.join(tmppath, 'part-00000')
# 
#                 data.to_csv(self.tmpfile, columns=self.columns, header=None,
#                             sep='\t', index=False)
#                 self._put()
# 
#     def run(self):
#         with self.output().temporary_path() as self.temp_output_path:
#             self.do_normalize_job()
# 
#     def requires(self):
#         return _next_task(self, self.next_task)(**_params(self))
# 
# 
# class ZoaDemoJoiningTask(CASparkSubmitTask, DDParamsMixin, metaclass=abc.ABCMeta):
#     date = luigi.DateParameter(positional=False)
# 
#     @property
#     @abc.abstractmethod
#     def executor(self):
#         pass
# 
#     @property
#     @abc.abstractmethod
#     def next_task(self):
#         pass
# 
#     @property
#     def entry_class(self):
#         return ('com.vng.zing.zudm_user_interest.profile.'
#                 + self.executor)
# 
#     def output(self):
#         templated_path = DM_DIR + '{folder}/%Y/%m/%d/'
# 
#         path = self.dd_format(templated_path, folder=self.folder)
#         return VngHdfsTarget(path)
# 
#     def requires(self):
#         params_dict = _params(self)
#         yield _next_task(self, 'DemoLogs')(**params_dict)
#         yield _next_task(self, self.next_task)(**params_dict)
# 
#     def app_options(self):
#         inputs = ','.join(self._inputs())
#         return ['--input', inputs, '--output', self.temp_output_path, '--decay', "true"]
# 
# 
# class d90ExternalLogsTask(luigi.ExternalTask, metaclass=abc.ABCMeta):
#     date = luigi.DateParameter(positional=False)
# 
#     def output(self):
#         return luigi.contrib.hdfs.HdfsTarget(self.path)
# 
#     @property
#     @abc.abstractmethod
#     def folder(self):
#         pass
# 
#     def complete(self):
#         templated_path = ('/data/zte/rd/user_interest/'
#                           'd90/{}/'
#                           '%Y/%m/%d/')
#         self.path = self.date.strftime(templated_path.format(self.folder))
#         if (_hadoopcli_client().exists(self.path + "_SUCCESS")):
#             return True
#         return False
# 
# 
# class SparkTask(common.SparkTask):
#     date = luigi.DateParameter(positional=False)
# 
#     @property
#     def entry_class(self):
#         return self.executor
# 
#     @property
#     @abc.abstractmethod
#     def folder(self):
#         pass
# 
#     @property
#     @abc.abstractmethod
#     def executor(self):
#         pass
# 
#     @property
#     @abc.abstractmethod
#     def next_task(self):
#         pass
# 
#     def output(self):
#         templated_path = DM_DIR + '{folder}/%Y/%m/%d/'
#         path = self.dd_format(templated_path, folder=self.folder)
#         return VngHdfsTarget(path)
# 
#     def requires(self):
#         yield _next_task(self, self.next_task)(**_params(self))
# 
# 
# class ExternalLogsTask(luigi.ExternalTask, metaclass=abc.ABCMeta):
#     date = luigi.DateParameter(positional=False)
# 
#     def output(self):
#         templated_path = DM_DIR + '{}/%Y/%m/%d/'
#         self.path = self.date.strftime(templated_path.format(self.folder))
#         return luigi.contrib.hdfs.HdfsTarget(self.path)
# 
#     @property
#     @abc.abstractmethod
#     def folder(self):
#         pass
